# -*- coding: utf-8 -*-
#%% load packages
# from ixmp import ixDatastructure
import ixmp
import iamc_tree
import numpy as np
import pandas as pd
import utils
import inspect
import os
import glob
import sys

from functools import cmp_to_key

# **TODO** This is very bad no good HACK and *REALLY* needs to be refactored
#global ds
years = None
firstmodelyear = None
all_tecs = None
regions = None


#%% Unit conversion - Input unit name : output unit name : conversion (multiplication) factor
unit_conversion = {
    'GWa': {
        'EJ/yr': .03154,
        'GWa': 1.,
        'MWa': 1000,
        'ZJ': .00003154,
        'km3/yr': 1.,
        'TWa': .001,
        'tractors': 1.,
        'bpkm': 0.00166,
        'btkm': 0.035,
    },
    'EJ/yr': {
        'ZJ': .001,
    },
    'Mt CO2/GWa': {
        'Mt CO2/GWa': 1.,
    },
    'y': {
        'years': 1.,
    },
    # Emissions currently have the units ???
    '???': {
        # Model units for CO2 are in MtCO2
        'Mt CO2/yr': 1.,
        'Mt CO2-equiv/yr': 1.,
        '???': 1.,
    },
    'USD/GWa': {
        'US$2010/GWa': 1.,
        'US$2010/kW/yr': .000001,
        'US$2010/kW': .000001,
        'US$2010/kWh': .000008760,
        'billion USD$2010/yr': (1. / 1000000000),
        'US$2010/GJ': 0.03171 * 1.,
    },
    'USD/GW': {
        'US$2010/kW': .000001,
        'US$2010/kW/yr': .000001,
        'billion USD$2010/yr': (1. / 1000000000),
    },
    'US$2010/MtCO2': {
        'US$2010/MtCO2': 1.,
        'US$2010/tCO2': .000001,
    },
}

#%% IAMC index
iamc_idx = ['Model', 'Scenario', 'Region', 'Variable', 'Unit']
index_order = ['Model', 'Region', 'Technology',
               'Commodity', 'Unit', 'Mode', 'Grade', 'Vintage']
#%% Define general functions


def combineDict(*args):
    result = {}
    for dic in args:
        for key in (result.keys() | dic.keys()):
            if key in dic:
                if type(dic[key]) is list:
                    result.setdefault(key, []).extend(dic[key])
                else:
                    result.setdefault(key, []).append(dic[key])
    return result


def fil(df, fil, factor, unit_out=None):
    """ Uses predefined values from a fil file
    """
    #ixmp_pth = ixmp.__path__
    #inf = os.path.join(ixmp_pth[0], 'fil_files', '*-{}.fil'.format(fil))
    msg_data_path = os.environ['MESSAGE_DATA_PATH']
    pp_path = '{}\\post-processing'.format(msg_data_path)
    inf = os.path.join(pp_path, 'fil_files', '*-{}.fil'.format(fil))
    files = glob.glob(inf)
    dfs = []
    for f in files:
        # print(f)
        reg = os.path.basename(f).split('-')[0]
        dftmp = pd.read_csv(f)
        dftmp.loc[:, 'Region'] = reg
        dfs.append(dftmp)
    df_fil = pd.concat(dfs)
    df_fil.Region = df_fil.Region.map(regions)
    df_fil = df_fil.set_index(['Region'])
    df_fil = df_fil[df_fil.Variable == factor].drop('Variable', axis=1)
    for cols in numcols(df_fil):
        df_fil = df_fil.rename(columns={cols: int(cols)})
    df = df_fil.fillna(0) * df.fillna(0)
    df.loc[:, 'Unit'] = '???'
    if unit_out:
        for col in numcols(df):
            df.loc[:, col] = df.apply(lambda row: row[col] *
                                      unit_conversion[row.Unit][unit_out], axis=1)
    df = df.drop('Unit', axis=1)
    return(df)


def group(df, value=0, groupby=['Region']):
    """ Groupby function for dataframe

    Parameters
    ----------
    df : dataframe
    value : numeric value
    groupby : list
        List of column headers by which the dataframe should be re-grouped

    Returns
    -------
    df : dataframe
    """
    df = df.fillna(value).reset_index()
    if 'Vintage' in df.columns:
        df.loc[:, 'Vintage'] = df.loc[:, 'Vintage'].astype('object')
    df = df.groupby(groupby).sum()
    return(df)


def aggr_glb(df):
    """ Overwrites all regional values with the global value

    Parameters
    ----------
    df : dataframe

    Returns
    -------
    df : dataframe
    """
    for reg in regions:
        df.loc[regions[reg]] = df.loc['World'].values
    return(df)


def aggr_reg(df):
    """ Overwrites all regional values with the sum over regions

    Parameters
    ----------
    df : dataframe

    Returns
    -------
    df : dataframe
    """
    df_tmp = df.copy().reset_index()
    vals = df_tmp[df_tmp.Region != 'World'].set_index(['Region']).sum().values
    for reg in regions:
        df.loc[regions[reg]] = vals
    return(df)


def numcols(df):
    """ Retrieves numeric columns of a dataframe.

    Parameters
    ----------
    df : dataframe

    Returns
    -------
    list : list
        column names of numeric columns
    """

    dtypes = df.dtypes
    return [i for i in dtypes.index if dtypes.loc[i].name.startswith(('float', 'int'))]


def nonnumcols(df):
    """ Retrieves nonnumeric columns of a dataframe.

    Parameters
    ----------
    df : dataframe

    Returns
    -------
    list : list
        column names of numeric columns
    """

    values = diff(df.columns.tolist(), numcols(df))
    values.sort(key=lambda x: index_order.index(x))
    return(values)


def diff(l1, l2):

    vals = [x for x in l1 if x not in l2]
    return(vals)


def _convert_units(df, unit_out):
    """ Converts and renames units.

    Parameters
    ----------
    df : dataframe
    unit_out : string
        unit to which output should be converted. the unit in the column "Unit" is the conversion input unit.
        the input and output unit as well as the conversion factor needs to be defined in the python-variable: unit_conversion

    Returns
    -------
    df : dataframe
    """

    for col in numcols(df):
        if col == 'Vintage':
            continue
        df.loc[:, col] = df.apply(lambda row: row[col] * unit_conversion[row.Unit][unit_out], axis=1)
    df.Unit = unit_out
    return(df)


def cum_vals(df):
    """ Cumulates values over a timeseries and converts annual to period-length values.

    Parameters
    ----------
    df : dataframe

    Returns
    -------
    df : dataframe
    """

    col = numcols(df)
    for i in range(len(col)):
        if i == len(col) - 1:
            df.loc[:, col[i]] = df.apply(lambda row: (
                row[col[i - 1]] + (row[col[i]] * (10))), axis=1)
        elif i == 0:
            df.loc[:, col[i]] = df.apply(lambda row: (
                row[col[i]] * (col[i + 1] - col[i])), axis=1)
        else:
            df.loc[:, col[i]] = df.apply(lambda row: (
                row[col[i - 1]] + (row[col[i]] * (col[i + 1] - col[i]))), axis=1)
    return(df)


def write_xlsx(df, model, scenario, path):
    """ Writes final results dataframe to xlsx file.

    Parameters
    ----------
    df : dataframe
    model : string
        model name
    scenario : string
        scenario name
    path : string
        path to where the xlsx file should be written

    """

    writer = pd.ExcelWriter(os.path.join(path, '{}_{}.xlsx'.format(model, scenario)),
                            engine='xlsxwriter')
    df.to_excel(writer, sheet_name='data', index=False)
    writer.save()


def make_outputdf(vars, units, model, scenario, param='sum', glb=True, weighted_by=None):
    """ Data is reformatted to the iamc-template output

    global data is derived bu summing over the 11 Regions + World

    Parameters
    ----------
    vars : dictionary
        output data to be converted into iamc-template format
    units : string
        units of the output
    model : string
        model name
    scenario : string
        scenario name
    param : string (optional, default = 'sum')
        methods with which the global value is derived from the regional numbers - alternatives include max, mean,
    glb : True/False (optional, default = True)
        if True then global values will be calculated


    Returns
    -------
    df : dataframe
        index : iamc_index
    """

    dfs = []
    # Adds variable names to dataframe and combines all data into a single
    # dataframe
    for var in vars:
        df = vars[var]
        df.loc[:, 'Model'] = model
        df.loc[:, 'Scenario'] = scenario
        df.loc[:, 'Variable'] = var
        # Currently, units are inserted manually because of problems with
        # multiplication of dataframes
        df.loc[:, 'Unit'] = units
        if glb:
            df = gen_GLB(df, param, weighted_by)
        else:
            df = df.reset_index()
        df = df[iamc_idx + years]
        dfs.append(df)
    return(pd.concat(dfs))


def gen_GLB(df, param, weighted_by):
    """ Aggregates results from individual regions onto global region.

    If values are present for the global regions these will be accounted for in the process.

    Parameters
    ----------
    df : dataframe
    param : string (can be either sum/max/mean/weighted_avg) -> if weighted_avg is passed then the values indexed over the region must be passed

    Returns
    -------
    df : dataframe
    """

    df = df.fillna(value=0).reset_index()
    if param == 'sum':
        df_tmp = df.groupby(['Model', 'Scenario', 'Variable',
                             'Unit', ]).sum().reset_index()
    elif param == 'max':
        df_tmp = df.groupby(['Model', 'Scenario', 'Variable',
                             'Unit', ]).max().reset_index()
    elif param == 'mean':
        # Global region needs to be dropped or else it is used for calcualting
        # the mean
        df_tmp = df[df.Region != 'World']
        df_tmp = df_tmp.groupby(['Model', 'Scenario', 'Variable',
                                 'Unit', ]).mean().reset_index()
    elif param == 'weighted_avg':
        weighted_by = weighted_by.reset_index()
        weighted_by = weighted_by[
            weighted_by.Region != 'World'].set_index('Region')
        df_tmp = df[df.Region != 'World']
        df_tmp = df_tmp.set_index(iamc_idx)
        df_tmp = df_tmp * weighted_by
        df_tmp = df_tmp.reset_index().groupby(
            ['Model', 'Scenario', 'Variable', 'Unit', ]).sum()
        df_tmp = (df_tmp / weighted_by.sum()).fillna(0).reset_index()

    df_tmp.loc[:, 'Region'] = 'R11_GLB'
    df_tmp.Region = df_tmp.Region.map(regions)
    df_tmp = df_tmp.set_index(iamc_idx)
    df = df.set_index(iamc_idx)
    df = df_tmp.combine_first(df).reset_index()
    return(df)


def iamc_it(df, what, xlsx, rm_totals=False):
    """ Creates any missing parent variables if these are missing and adds a pre-fix to the variable name.

    Variable parent/child relationships are determined by separating the variable name by "|".

    Parameters
    ----------
    df : dataframe
    what : string
        variable pre-fix
    xlsx : string
        name of the xlsx fiel (most commonly and iamc_template) in which the variable tree is defined and where the aggregates are defined
    rm_totals : True/False (optional, default = False)
        if True then all totals a removed and recalculated. 


    Returns
    -------
    df : dataframe
    """

    root = what
    df = iamc_tree.sum_iamc_sectors(
        df, mode='Add', root=root, cleanname=False).reset_index()
    if rm_totals:
        df = df[df.Variable != what]
    df = utils.EmissionsAggregator(
        df, xlsx=xlsx).add_variables(append=False).df
    return(df)


def _make_emptydf(tec, vintage=None, grade=None, units='GWa'):
    """ Creates an empty dataframe for cases where data no entries can be found in the database for a single or set of technolgies.

    This function should only be used to create placeholders for data that cannot be retrieved from the database and which will be procssed in subsequent steps.

    Parameters
    ----------
    tec : string or list
        technology name
    vintage : True/False (optional, default = False)
        switch for creating an empty dataframe either with or with-out the column "Vintage"
    grade : True/False (optional, default = False)
        switch for creating an empty dataframe either with or with-out the column "Grade"
    units : string (optional, default = 'GWa')
        value which will be enetered into the column "Unit"

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage (optional), Mode, Unit, Grade (optional)
    """

    dfs = []
    for t in tec:
        if vintage:
            df = pd.DataFrame(data={
                'Region': list(regions.keys()),
                'Technology': t,
                'Vintage': firstmodelyear,
                'Mode': 'standard',
                'Unit': units,
            })
        elif grade:
            df = pd.DataFrame(data={
                'Region': list(regions.keys()),
                'Commodity': t,
                'Unit': units,
                'Grade': 'a',
            })
        else:
            df = pd.DataFrame(data={
                'Region': list(regions.keys()),
                'Technology': t,
                'Mode': 'standard',
                'Unit': units,
            })
        dfs.append(df)
    df = pd.concat(dfs)
    if 'Vintage' in df.columns:
        df.loc[:, 'Vintage'] = df.loc[:, 'Vintage'].astype('object')
    return(df)


def _make_zero():
    """ Creates a dataframe in the iamc output format.

    This function should only be used as a placeholder for reporting variables.

    Returns
    -------
    df : dataframe
       index: iamc_index(values are "0")
    """

    df = pd.DataFrame(data={
        'Region': list(regions.keys())})
    df = _clean_up_regions(df)
    df = _clean_up_years(df)
    df = _clean_up_formatting(df)
    return(df)


def _clean_up_regions(df, units=None):
    """ Converts region names from the database format into desired reporting region names.

    Should a region be missing, it is appended to the dataframe. values = 0.

    Define desired reporting region names in python - variable: "regions".

    Parameters
    ----------
    df : dataframe
    units : string(optional, default=None)
        inserts units into unit column which may be required for unit conversion

    Returns
    -------
    df : dataframe
        index: Region, Technology(optional) or Commodity(optional), Unit, Vintage(optional), Mode, Grade(optional)
    """
    if not units:
        if 'Unit' in df.columns:
            df_unit = df.Unit.unique()
            if len(df_unit) > 1:
                print((inspect.stack()[0][
                      3], ': there are more than 1 unit in the dataframe:', df_unit))
                units = 'GWa'
            else:
                units = df.Unit.unique()[0]
        else:
            units = 'GWa'

    # Makes exception if only a world value is available for the carbon price
    # In MESSAGE_ix_legacy, the carbon price was returned for all regions when a budget is applied. In the January, 2018 version of MESSAGEix, only a global value is returned.
    # Therefore the value needs to be replicated for all other regions. This is only done when there is only a single carbon price entry for the region 'World'.
    if 'Technology' in df.columns and 'TCE' in df.Technology.unique().tolist() and df.Region.unique().tolist() == ['World']:
        dfs = []
        dfs.append(df)
        for reg in regions.keys():
            tmp = df.copy()
            tmp.Region = reg
            dfs.append(tmp)
        df = pd.concat(dfs)

    # Removes aggregate region 'WORLD'
    df = df[df['Region'] != 'World']

    # for reg in list(regions.keys()):
    for reg in regions.keys():
        if reg not in df.Region.unique():
            if 'Technology' in df.columns:
                for tec in df.Technology.unique():
                    if 'Mode' in df.columns:
                        if 'Vintage' in df.columns:
                            df = pd.DataFrame(np.array([[reg, tec, units, firstmodelyear, 'standard']]), columns=[
                                              'Region', 'Technology', 'Unit', 'Vintage', 'Mode']).append(df)
                        else:
                            df = pd.DataFrame(np.array([[reg, tec, units, 'standard']]), columns=[
                                              'Region', 'Technology', 'Unit', 'Mode']).append(df)
                    elif 'Unit' in df.columns:
                        if 'Vintage' in df.columns:
                            df = pd.DataFrame(np.array([[reg, tec, units, firstmodelyear]]), columns=[
                                              'Region', 'Technology', 'Unit', 'Vintage']).append(df)
                        elif 'Grade' in df.columns:
                            df = pd.DataFrame(np.array([[reg, tec, units, 'a']]), columns=[
                                              'Region', 'Technology', 'Unit', 'Grade']).append(df)
                        else:
                            df = pd.DataFrame(np.array([[reg, tec, units]]), columns=[
                                              'Region', 'Technology', 'Unit']).append(df)
                    else:
                        df = pd.DataFrame(np.array([[reg, tec]]), columns=[
                            'Region', 'Technology']).append(df)

            elif 'Commodity' in df.columns:
                for tec in df.Commodity.unique():
                    if 'Mode' in df.columns:
                        if 'Vintage' in df.columns:
                            df = pd.DataFrame(np.array([[reg, tec, units, firstmodelyear, 'standard']]), columns=[
                                              'Region', 'Commodity', 'Unit', 'Vintage', 'Mode']).append(df)
                        else:
                            df = pd.DataFrame(np.array([[reg, tec, units, 'standard']]), columns=[
                                              'Region', 'Commodity', 'Unit', 'Mode']).append(df)
                    else:
                        if 'Vintage' in df.columns:
                            df = pd.DataFrame(np.array([[reg, tec, units, firstmodelyear]]), columns=[
                                              'Region', 'Commodity', 'Unit', 'Vintage']).append(df)
                        elif 'Grade' in df.columns:
                            df = pd.DataFrame(np.array([[reg, tec, units, 'a']]), columns=[
                                              'Region', 'Commodity', 'Unit', 'Grade']).append(df)
                        else:
                            df = pd.DataFrame(np.array([[reg, tec, units]]), columns=[
                                              'Region', 'Commodity', 'Unit']).append(df)
            else:
                if 'Mode' in df.columns:
                    if 'Vintage' in df.columns:
                        df = pd.DataFrame(np.array([[reg, units, firstmodelyear, 'standard']]), columns=[
                                          'Region', 'Unit', 'Vintage', 'Mode']).append(df)
                    else:
                        df = pd.DataFrame(np.array([[reg, units, 'standard']]), columns=[
                                          'Region', 'Unit', 'Mode']).append(df)
                else:
                    if 'Vintage' in df.columns:
                        df = pd.DataFrame(np.array([[reg, units, firstmodelyear]]), columns=[
                                          'Region', 'Unit', 'Vintage']).append(df)
                    elif 'Grade' in df.columns:
                        df = pd.DataFrame(np.array([[reg, units, 'a']]), columns=[
                                          'Region', 'Unit', 'Grade']).append(df)
                    else:
                        df = pd.DataFrame(np.array([[reg, units]]), columns=[
                                          'Region', 'Unit']).append(df)

    df.Region = df.Region.map(regions)
    if 'Vintage' in df.columns:
        df.loc[:, 'Vintage'] = df.loc[:, 'Vintage'].apply(np.int64)
        df.loc[:, 'Vintage'] = df.loc[:, 'Vintage'].astype('object')
    return(df)


def _clean_up_vintage(ds, df, units=None):
    """ Checks if a vintage year is found for each region.

    If a vintage year is missing it is appended to the dataframe. values = 0.

    Parameters
    ----------
    ds : ix-datastructure
    df : dataframe
    units: string(optional, default=None)
        inserts units into unit column which may be required for unit conversion

    Returns
    -------
    df : dataframe
        index: Region, Technology, Unit, Vintage(optional), Mode(optional)
    """
    if not units:
        if 'Unit' in df.columns:
            df_unit = df.Unit.unique()
            if len(df_unit) > 1:
                print((inspect.stack()[0][
                      3], ': there are more than 1 unit in the dataframe:', df_unit))
                units = 'GWa'
            else:
                units = df.Unit.unique()[0]
        else:
            units = 'GWa'

    def set_standard(column, df):
        if column == 'Mode':
            values = df.Mode.unique().tolist()
        elif column == 'Region':
            values = [regions[reg] for reg in list(regions.keys())]
        elif column == 'Technology':
            values = df.Technology.unique().tolist()
        elif column == 'Unit':
            values = [units]
        elif column == 'Vintage':
            values = ds.set('year').tolist()
        return(values)

    import itertools
    import pandas as pd

    index = nonnumcols(df)

    reg = [regions[reg] for reg in list(regions.keys())]
    tec = df.Technology.unique().tolist()
    unit = [units]
    vintage = ds.set('year').tolist()
    #idx = pd.MultiIndex.from_tuples(list(itertools.product([set_standard(x,df) for x in nonnumcols(df)])),names=nonnumcols(df))
    if 'Mode' in index:
        mode = df.Mode.unique().tolist()
        idx = pd.MultiIndex.from_tuples(
            list(itertools.product(reg, tec, unit, mode, vintage)), names=index)
    else:
        idx = pd.MultiIndex.from_tuples(
            list(itertools.product(reg, tec, unit, vintage)), names=index)
    df_fill = pd.DataFrame(0, index=idx, columns=numcols(df)).reset_index()
    df_fill.loc[:, 'Vintage'] = df_fill.loc[:, 'Vintage'].apply(np.int64)
    df_fill.loc[:, 'Vintage'] = df_fill.loc[:, 'Vintage'].astype('object')
    df = df.set_index(index).combine_first(
        df_fill.set_index(index)).reset_index()
    return(df)


def compare(x, y):
    """Comparison function that is Python 2/3 robust"""
    if x == y:
        return 0
    try:
        if x < y:
            return -1
        else:
            return 1
    except TypeError as e:
        # The case where both are None is taken care of by the equality test
        if x is None:
            return -1
        elif y is None:
            return 1
        # Compare by type name
        if type(x) != type(y):
            return compare(type(x).__name__, type(y).__name__)
        elif isinstance(x, type):
            return compare(x.__name__, y.__name__)
        # Types are the same but a native compare didn't work, recursively
        # compare elements
        try:
            for a, b in zip(x, y):
                c = compare(a, b)
                if c != 0:
                    return c
        except TypeError:
            raise e

        return compare(len(x), len(y))


def _clean_up_years(df, method='ffill'):
    """ Checks if columns are missing an years.

    If a column is missing it is added. values = 0

    Years are defined in the model and are retrieved via the python - varaible: years

    Parameters
    ----------
    df : dataframe
    method : string (optional, default = 'forwardfill')
        possiblities for filling data for missing years.
        forwardfill -> fills future users with last available year
        zero -> fills with 0

    Returns
    -------
    df : dataframe
        index: the index of the input dataframe will be preserved
    """
    if method == 'zero':
        for yr in years:
            if yr not in numcols(df):
                df.loc[:, yr] = 0
        df = df.fillna(0)
        oth_idx = sorted(nonnumcols(df), key=cmp_to_key(compare))
        yr_idx = sorted(numcols(df), key=cmp_to_key(compare))
        idx = oth_idx + yr_idx
        df = df.reindex(idx, axis=1)
    elif method == 'ffill':
        for yr in years:
            if yr not in numcols(df):
                df.loc[:, yr] = pd.np.nan
        oth_idx = sorted(nonnumcols(df), key=cmp_to_key(compare))
        yr_idx = sorted(numcols(df), key=cmp_to_key(compare))
        idx = oth_idx + yr_idx
        df = df.reindex(idx, axis=1)

        df = df.set_index(oth_idx)
        # use previous values to fill forward and anythin else with 0
        df = df.fillna(method='ffill', axis=1).fillna(0).reset_index()
    return(df)


def _clean_up_formatting(df):
    """ Indexing is set depending on input column names.

    Function checks for columns: Vintage, Grade, Mode

    Parameters
    ----------
    df : dataframe

    Returns
    -------
    df : dataframe
        index: Region, Technology (optional), Commodity (optional), Vintage (optional), Mode (optional), Grade (optional)
        the index will be set to all non-numerical columns with the exception of 'Vintage' which will also be part of the index structure.
        the column units is dropped
    """
    if 'Vintage' in df.columns:
        df.loc[:, 'Vintage'] = df.loc[:, 'Vintage'].apply(np.int64)
        df.loc[:, 'Vintage'] = df.loc[:, 'Vintage'].astype('object')

    yrs = [int(x) for x in numcols(df)]

    values = diff(df.columns.tolist(), yrs)
    values.sort(key=lambda x: index_order.index(x))
    values = [val for val in values if val != 'Unit']
    cols = values + yrs
    df = df[cols]
    df = df.set_index(values)

    return(df)


def _drap(df, pivot_col, drop=None, add=None, group=None):
    """ Drop, Renames, Adds and Pivots variables dataframes

    Parameters
    ----------

    df :  dataframe
    pivot_col : list
        a list containging two column names, of which the first tells the pivot_table function which column contains the values and
        the second indicates the index column which contains the year entries which are used to pivot the results.
    drop : list
        a list of columns to be dropped from the dataframe
    add : dictionary or list
        must contain two entries: the first is the new column name; the second is the value to be entered in that column
    group : list
        a list of columns over which the dataframe should be grouped

    Returns
    -------
    df : dataframe
        index: in IAMC style format - can contain some extra index entries (Mode, Grade, etc) over which an sum is formed later on in the script

    """

    col_newnames = {
        'node': 'Region',
        'node_loc': 'Region',
        'emission': 'Technology',
        'type_emission': 'Technology',
        'land_scenario': 'Technology',
        'technology': 'Technology',
        'unit': 'Unit',
        'mode': 'Mode',
        'year_vtg': 'Vintage',
        'grade': 'Grade',
        'commodity': 'Commodity',
    }

    # Drop columns if defined
    if drop:
        drop = [drop] if type(drop) == str else drop
        df = df.drop(drop, axis=1)

    # Groups dataframe
    if group:
        df = df.groupby(group).sum().reset_index()

    # Renames columns
    df = df.rename(columns=col_newnames)

    # Adds column with a spcified value
    if add:
        if type(add) == dict:
            for var in add.keys():
                df[var] = add[var]
        elif type(add) == list:
            df[add[0]] = df[add[1]]

    # An exception has to be made for the column "Vintage" as this is included
    # in the numcols; in some case 'Vintage' will be used for the years and
    # can therefore be in pivot_col
    df = df.pivot_table(pivot_col[0], [x for x in df.columns if (
        x not in pivot_col and x not in numcols(df)) or (x == 'Vintage' and x not in pivot_col)], pivot_col[1])

    return(df.reset_index())


def _retr_act_data(ds, ix, param, filter, units, convert=1):
    """ Output for a single or set of technolgies is retrieved.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'reference_activity' or 'ACT' (IX only)
    filter : dictionary
        filters specific to 'reference_activity' or 'ACT' tables
    units : string
        see unit doc
    convert : integer(optional, default = 1)
        0 turns off unit conversion
        1 turns on unit conversion

    Returns
    -------
    df : dataframe
        index: Region, Technology, Mode, Vintage(IX only)
    """

    tec = [filter['technology'][0]] if type(
        filter['technology'][0]) == str else filter['technology'][0]
    df = ds.var(
        param, filter) if ix else ds.par(param, filter)

    if df.empty:
        print((inspect.stack()[0][3], ': technology', tec, 'dataframe empty'))
        df = _make_emptydf(tec, vintage=1) if ix else _make_emptydf(tec)
    else:
        if ix:
            drop = ['time', 'mrg']
            group = ['node_loc', 'technology', 'year_act', 'year_vtg', 'mode']
            add = {'Unit': 'GWa'}
            df = _drap(df, ['lvl', 'year_act'],
                       add=add, drop=drop, group=group)
        else:
            drop = ['time']
            group = ['node_loc', 'technology', 'unit', 'year_act', 'mode']
            df = _drap(df, ['value', 'year_act'], drop=drop, group=group)

    df = _clean_up_regions(df)
    if ix:
        df = _clean_up_vintage(ds, df)
    df = _clean_up_years(df, method='zero')
    if convert and units is not None:
        df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_io_data(ds, ix, param, filter, method, formatting='standard'):
    """ Retrieves commodity - input or commodity - output coefficients for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'output' or 'input'
    filter : dictionary
        filters specific to technology, input, output tables
    method : string (optional, default is defined by the callinf function)
        possiblities for filling data for missing years.
        forwardfill -> fills future users with last available year
        zero -> fills with 0
    formatting : string (optional, default = 'standard')
        the formatting can be set to "default" in which case the "Vintage" will be preserved
        alternatively, the formatting can be set to "reporting" in which case values will be returned only for those cases where "year_act" == "year_vtg"

    Returns
    -------
    df : dataframe
        index: Region, Technology, Mode, Vintage( for IX and formatting == 'standard' only)
    """

    tec = [filter['technology'][0]] if type(
        filter['technology'][0]) == str else filter['technology'][0]
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology', tec, 'dataframe empty'))
        if ix and formatting != 'reporting':
            df = _make_emptydf(tec, vintage=1)
        else:
            df = _make_emptydf(tec)
    else:
        if ix and formatting != 'reporting':
            if param == 'input':
                drop = ['time_origin', 'commodity',
                        'level', 'node_origin', 'time']
            if param == 'output':
                drop = ['time_dest', 'commodity', 'level', 'node_dest', 'time']
            group = ['node_loc', 'technology', 'unit',
                     'year_act', 'year_vtg', 'mode']

        else:
            df = df[df.year_act == df.year_vtg]
            if param == 'input':
                drop = ['time_origin', 'commodity', 'level',
                        'node_origin', 'year_vtg', 'time']
            if param == 'output':
                drop = ['time_dest', 'commodity', 'level',
                        'node_dest', 'year_vtg', 'time']
            group = ['node_loc', 'technology', 'unit', 'year_act', 'mode']
        df = _drap(df, ['value', 'year_act'], drop=drop, group=group)

    df = _clean_up_regions(df)
    if ix and formatting != 'reporting':
        df = _clean_up_vintage(ds, df)
    df = _clean_up_years(df, method)
    df = _clean_up_formatting(df)
    return(df)


def _retr_emi_data(ds, ix, param, emifilter, tec, units):
    """ Retrieves coefficient for emissions

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param: string
        'relation_activity'
    emifilter: dictionary
        filters specific to relation tables
    tec: string or list
        name of relation
    units: string
        see unit doc

    Returns
    -------
    df: dataframe
        index: Region, Technology, Mode
    """

    filter = {'technology': tec} if emifilter is None else dict(
        list(emifilter.items()) + list({'technology': tec}.items()))
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology', tec, 'dataframe empty'))
        df = _make_emptydf(tec)
    else:
        df = df if ix else df[df.year_act == df.year_rel]
        drop = ['node_rel', 'relation', 'year_rel']
        df = _drap(df, ['value', 'year_act'], drop=drop)

    # Clean up operations
    df = _convert_units(df, units)
    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)
    return(df)


def _retr_cpf_data(ds, ix, param, tec, formatting='standard'):
    """ Retrieves capacity factor for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'capacity_factor'
    tec : string or list
        technology name
    formatting : string (optional, default = 'standard')
        the formatting can be set to "default" in which case the "Vintage" will be preserved
        alternatively, the formatting can be set to "reporting" in which case values will be returned only for those cases where "year_act" == "year_vtg"

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage(IX only)
    """

    filter = {'technology': tec}
    # checks if technology exists, if not then a proxy df is made.
    if tec not in all_tecs.values:
        print((inspect.stack()[0][3], ': technology',
               tec, 'not included in model'))
        if ix and formatting != 'reporting':
            df = _make_emptydf(tec, vintage=1)
        else:
            df = _make_emptydf(tec)
    else:
        df = ds.par(param, filter)
        if df.empty:
            print((inspect.stack()[0][3], ': technology',
                   tec, 'dataframe empty'))
            if ix and formatting != 'reporting':
                df = _make_emptydf(tec, vintage=1)
            else:
                df = _make_emptydf(tec)
        else:
            if ix and formatting != 'reporting':
                drop = ['time']
            else:
                df = df[df.year_act == df.year_vtg]
                drop = ['time', 'year_vtg']
            df = _drap(df, ['value', 'year_act'], drop=drop)

    # Clean up operations
    df = _clean_up_regions(df)
    if ix and formatting != 'reporting':
        df = _clean_up_vintage(ds, df)
    df = _clean_up_years(df)
    df = _clean_up_formatting(df)
    return(df)


def _retr_tic_data(ds, ix, param, tec, units):
    """ Retrieves total installed capacity for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'ref_capacity' or 'CAP' (IX only)
    tec : string or list
        technology name
    units : string
        see unit doc

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage
    """

    filter = {'technology': tec}
    if ix:
        df = ds.var(param, filter)
        if df.empty:
            print((inspect.stack()[0][3], ': technology',
                   tec, 'dataframe empty'))
            df = _make_emptydf(
                tec, vintage=1) if ix else _make_emptydf(tec)
        else:
            drop = ['mrg']
            add = {'Unit': 'GW'}
            df = _drap(df, ['lvl', 'year_act'], drop=drop, add=add)
    else:
        print((inspect.stack()[0][3],
               ': is not yet working for non-IX results'))
        df = _make_emptydf(tec)

    # Clean up operations
    df = _clean_up_regions(df, units=units)
    if ix:
        df = _clean_up_vintage(ds, df, units=units)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)
    return(df)


def _retr_extr_data(ds, ix, param, tec, units, method='zero'):
    """ Retrieves extracted resource quanitites

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param: string
        'ref_extraction' or 'EXT' (IX only)
    tec: string or list
        extraction technology name
    units: string
        see unit doc
    method : string (optional, default = 'zero')
        possiblities for filling data for missing years.
        forwardfill -> fills future users with last available year
        zero -> fills with 0

    Returns
    -------
    df : dataframe
        index: Region, Commodity, Grade
    """

    filter = {'commodity': tec}
    df = ds.var(
        param, filter) if ix else ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology', tec, 'dataframe empty'))
        df = _make_emptydf(tec, grade=1)
    else:
        add = {'Unit': 'GWa'}
        if ix:
            drop = ['mrg']
            df = _drap(df, ['lvl', 'year'], drop=drop, add=add)
        else:
            df = _drap(df, ['value', 'year'], add=add)
    # Clean up operations
    df = _clean_up_regions(df)
    df = _clean_up_years(df, method)
    df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_histextr_data(ds, ix, param, tec, units, method='zero'):
    """ Retrieves pre - 2020 extracted resource quanitites (IX only)

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'historical_extraction'
    tec : string or list
        extraction technology name
    units : string
        see unit doc
    method : string (optional, default = 'zero')
        possiblities for filling data for missing years.
        forwardfill -> fills future users with last available year
        zero -> fills with 0

    Returns
    -------
    df: dataframe
        index: Region, Commodity, Grade
    """

    filter = {'commodity': tec}
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology', tec, 'dataframe empty'))
        df = _make_emptydf(tec, grade=1)
    else:
        add = {'Unit': 'GWa'}
        df = _drap(df, ['value', 'year'], add=add)
    # Clean up operations
    df = _clean_up_regions(df)
    df = _clean_up_years(df, method)
    df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_rel_data(ds, ix, param, relfilter, tec):
    """ Retrieves coefficient with which a technology writes into a given relation for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'relation_activity'
    relfilter : dictionary
        filters specific to relation tables
    tec : string or list
        technology name

    Returns
    -------
    df : dataframe
        index: Region, Technology, Mode
    """

    # Checks for additonal keyword arguments
    filter = {'technology': tec} if relfilter is None else dict(
        list(relfilter.items()) + list({'technology': tec}.items()))
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology', tec, 'dataframe empty'))
        df = _make_emptydf(tec)
    else:
        df = df if ix else df[df.year_act == df.year_rel]
        drop = ['node_rel', 'relation', 'year_rel']
        df = _drap(df, ['value', 'year_act'], drop=drop)

    # Clean up operations
    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)
    return(df)


def _retr_nic_data(ds, ix, param, tec, units):
    """ Retrieves new installed capacity for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'ref_new_capacity' or 'CAP_NEW' (IX only)
    tec : string or list
        technology name
    units : string
        see unit doc

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage
    """

    filter = {'technology': tec}
    if ix:
        df = ds.var(param, filter)
        # add a column "year_act"
        df.loc[:, 'year_act'] = df.loc[:, 'year_vtg']
        if df.empty:
            print((inspect.stack()[0][3], ': technology',
                   tec, 'dataframe empty'))
            df = _make_emptydf(tec, vintage=1)
        else:
            drop = ['mrg']
            add = {'Unit': 'GW'}
            df = _drap(df, ['lvl', 'year_act'], drop=drop, add=add)
    else:
        df = ds.par(param, filter)
        if df.empty:
            print((inspect.stack()[0][3], ': technology',
                   tec, 'dataframe empty'))
            df = _make_emptydf(tec)
        else:
            add = {'Unit': 'GW'}
            df = _drap(df, ['value', 'Vintage'], add=add)

    # Clean up operations
    df = _clean_up_regions(df, units=units)
    if ix:
        df = _clean_up_vintage(ds, df, units=units)
    # Method is 'zero' so that the new installed capacity is only retained for
    # the single year in which it is built
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)
    return(df)


def _retr_capcost_data(ds, param, tec, units):
    """ Retrieves capital cost for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    param : string
        'inv_cost' 
    tec : string or list
        technology name
    units : string
        see unit doc

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage
    """

    filter = {'technology': tec}
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology',
               tec, 'dataframe empty'))
        df = _make_emptydf(tec, units='USD/GWa')
    else:
        df = _drap(df, ['value', 'Vintage'])

    # Clean up operations
    df = _clean_up_regions(df, units='USD/GW')
    df = _clean_up_years(df)
    df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_fom_data(ds, ix, param, tec, units, formatting):
    """ Retrieves fix O&M cost for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'fix_cost' 
    tec : string or list
        technology name
    units : string
        see unit doc
    formatting : string (optional, default = 'standard')
        the formatting can be set to "default" in which case the "Vintage" will be preserved
        alternatively, the formatting can be set to "reporting" in which case values will be returned only for those cases where "year_act" == "year_vtg"

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage
    """

    filter = {'technology': tec}
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology',
               tec, 'dataframe empty'))
        if formatting == 'standard' and ix:
            df = _make_emptydf(tec, vintage=1, units='USD/GWa')
        if formatting == 'reporting' or not ix:
            df = _make_emptydf(tec, units='USD/GWa')
    else:
        if formatting == 'standard' and ix:
            df = _drap(df, ['value', 'year_act'])
        if formatting == 'reporting' or not ix:
            df = df[df.year_act == df.year_vtg]
            drop = ['year_act']
            df = _drap(df, ['value', 'Vintage'], drop=drop)

    # Clean up operations
    df = _clean_up_regions(df, units='USD/GWa')
    if formatting == 'standard' and ix:
        df = _clean_up_vintage(ds, df, units='USD/GWa')
    df = _clean_up_years(df)
    df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_vom_data(ds, ix, param, tec, units, formatting):
    """ Retrieves variable O&M cost for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'var_cost' 
    tec : string or list
        technology name
    units : string
        see unit doc
    formatting : string (optional, default = 'standard')
        the formatting can be set to "default" in which case the "Vintage" will be preserved
        alternatively, the formatting can be set to "reporting" in which case values will be returned only for those cases where "year_act" == "year_vtg"

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage
    """

    filter = {'technology': tec}
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology',
               tec, 'dataframe empty'))
        if formatting == 'standard' and ix:
            df = _make_emptydf(tec, vintage=1, units='USD/GWa')
        if formatting == 'reporting' or not ix:
            df = _make_emptydf(tec, units='USD/GWa')
    else:
        if formatting == 'standard' and ix:
            drop = ['time']
            df = _drap(df, ['value', 'year_act'], drop=drop)
        if formatting == 'reporting' or not ix:
            df = df[df.year_act == df.year_vtg]
            drop = ['time', 'year_act']
            df = _drap(df, ['value', 'Vintage'], drop=drop)

    # Clean up operations
    df = _clean_up_regions(df, units='USD/GWa')
    if formatting == 'standard' and ix:
        df = _clean_up_vintage(ds, df, units='USD/GWa')
    df = _clean_up_years(df)
    df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_pll_data(ds, param, tec, units):
    """ Retrieves technical lifetime for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    param : string
        'var_cost' 
    tec : string or list
        technology name
    units : string
        see unit doc

    Returns
    -------
    df : dataframe
        index: Region, Technology, Vintage
    """

    filter = {'technology': tec}
    df = ds.par(param, filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology',
               tec, 'dataframe empty'))
        df = _make_emptydf(tec, units='y')
    else:
        df = _drap(df, ['value', 'Vintage'])

    # Clean up operations
    df = _clean_up_regions(df, units='y')
    df = _clean_up_years(df)
    df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_crb_prc(ds, units):
    """ Retrieves carbon price.

    Parameters
    ----------
    ds : ix-datastructure
    units : string
        see unit doc

    Returns
    -------
    df : dataframe
        index: Region, Technology
    """

    df = ds.var('PRICE_EMISSION', {'type_tec': ['all']})
    if df.empty:
        print((inspect.stack()[0][3], ': PRICE_EMISSION dataframe empty'))
        df = _make_emptydf('TCE', units='US$2010/MtCO2')
    else:
        drop = ['type_tec', 'mrg']
        add = {'Unit': 'US$2010/MtCO2'}
        df = _drap(df, ['lvl', 'year'], drop=drop, add=add)

    # Clean up operations
    df = _clean_up_regions(df, units='US$2010/MtCO2')
    df = _clean_up_years(df, method='zero')
    if units:
        df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_ene_prc(ds, units, enefilter):
    """ Retrieves energy price.

    Parameters
    ----------
    ds : ix-datastructure
    units : string
        see unit doc
    enefilter : dictionary
        filter specific to "PRICE_COMMODITY' table

    Returns
    -------
    df : dataframe
        index: Region, Technology (where Technology == Commodity)
    """
    filter = enefilter
    df = ds.var('PRICE_COMMODITY', filter)
    if df.empty:
        print((inspect.stack()[0][3], ': technology',
               filter['commodity'], 'dataframe empty'))
        df = _make_emptydf(filter['commodity'], units='USD/GWa')
    else:
        drop = ['level', 'mrg', 'time']
        add = {'Unit': 'USD/GWa'}
        df = _drap(df, ['lvl', 'year'], drop=drop, add=add)

    # Clean up operations
    df = _clean_up_regions(df, units='USD/GWa')
    df = _clean_up_years(df, method='zero')
    df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_demands(ds, ix, commodity, level, units):
    """ Retrieves demands.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    commodity : string
        the commodity on which the results should be filtered 
    level : string
        the level on which the results should be filtered 
    units : string
        see unit doc

    Returns
    -------
    df : dataframe
        index: Region, Technology
    """
    filter = {'commodity': commodity, 'level': [level]}

    # Retrieves par('demand_fixed') if var('DEMAND') doesnt exist
    if 'DEMAND' in ds.var_list():
        df = ds.var('DEMAND', filter)
        if df.empty:
            print((inspect.stack()[0][3], ': DEMAND dataframe empty'))
            df = _make_emptydf(commodity)
        else:
            drop = ['time', 'mrg', 'level', 'commodity']
            add = {'Unit': 'GWa'}
            df = _drap(df, ['lvl', 'year'], drop=drop, add=add)
        df_macro = df
    if 'DEMAND' not in ds.var_list() or not ix:
        df = ds.par('demand', filter)
        if df.empty:
            print((inspect.stack()[0][3], ': DEMAND dataframe empty'))
            df = _make_emptydf(commodity)
        else:
            drop = ['time', 'level', 'commodity']
            df = _drap(df, ['value', 'year'], drop=drop)
        df_message = df
    if not ix and 'DEMAND' in ds.var_list():
        df_macro = df_macro.set_index(['Region', 'Unit']).fillna(0)
        df_message = df_message.set_index(['Region', 'Unit']).fillna(0)
        df_message = df_message.drop(df_macro.columns, axis=1)
        df = df_message.add(df_macro, fill_value=0).fillna(0).reset_index()

    # Clean up operations
    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    if units:
        df = _convert_units(df, units)
    df = _clean_up_formatting(df)
    return(df)


def _retr_emif_data(ds, ix, param, emiflt, tec, emi_units=None):
    """ Retrieves coefficient with which a technology writes into a given relation for a single or set of technolgies.

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'
    param : string
        'emission_factor'
    emiflt : dictionary
        filters specific to emission_factor tables
    tec: string or list
        technology name

    Returns
    -------
    df: dataframe
        index: Region, Technology, Mode
    """

    # Checks for additonal keyword arguments
    df = ds.par(param, emiflt)
    if df.empty:
        print((inspect.stack()[0][3], ': technology', tec, 'dataframe empty'))
        if ix:
            df = _make_emptydf(tec, vintage=1, units=emi_units)
        else:
            df = _make_emptydf(tec, units='-')
    else:
        if ix:
            drop = ['emission']
            df = _drap(df, ['value', 'year_act'], drop=drop)
        else:
            df = df[df.year_act == df.year_vtg]
            drop = ['emission', 'year_vtg']
            df = _drap(df, ['value', 'year_act'], drop=drop)

    # Clean up operations
    df = _clean_up_regions(df)
    if ix:
        df = _clean_up_vintage(ds, df, units=emi_units)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)
    return(df)


def _retr_par_MERtoPPP(ds):
    """ Retrieves parameter conversion factor from GDP(MER) to GDP (PPP)

    Parameters
    ----------
    ds : ix-datastructure

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    df = ds.par('MERtoPPP')
    if df.empty:
        print((inspect.stack()[0][3], ': parameter MERtoPPP dataframe empty'))
        df = _make_emptydf('MERtoPPP')
    else:
        drop = ['unit']
        add = {'Technology': 'MERtoPPP'}
        df = _drap(df, ['value', 'year'], drop=drop, add=add)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)

    return(df)


def _retr_var_consumption(ds):
    """ Retrieve variable "Consumption"

    Parameters
    ----------
    ds : ix-datastructure

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    df = ds.var('C')
    if df.empty:
        print((inspect.stack()[0][3],
               ': variable C (Consumption) dataframe empty'))
        df = _make_emptydf('C')
    else:
        drop = ['mrg']
        add = {'Technology': 'C'}
        df = _drap(df, ['lvl', 'year'], drop=drop, add=add)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)

    return(df)


def _retr_var_gdp(ds):
    """ Retrieve variable "GDP"

    Parameters
    ----------
    ds : ix-datastructure

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    df = ds.var('GDP')
    if df.empty:
        print((inspect.stack()[0][
              3], ': variable GDP dataframe empty, using parameter: gdp_calibrate'))
        df = ds.par('gdp_calibrate')
        if df.empty:
            print((inspect.stack()[0][3],
                   ': parameter gdp_calibrate dataframe empty'))
            df = _make_emptydf('GDP')
        else:
            drop = ['mrg']
            add = {'Technology': 'GDP'}
            df = _drap(df, ['lvl', 'year'], drop=drop, add=add)
    else:
        drop = ['mrg']
        add = {'Technology': 'GDP'}
        df = _drap(df, ['lvl', 'year'], drop=drop, add=add)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)

    return(df)


def _retr_land_act(ds, ix):
    """ Retrieve activity of land-use technologies

    Parameters
    ----------
    ds : ix-datastructure
    ix : string
        'True' or 'False'

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    df = ds.var('LAND') if ix else ds.par('historical_land')
    if df.empty:
        print((inspect.stack()[0][
              3], ': variable LAND dataframe empty. Please check that correct version of the land emulator is being used'))
        sys.exit(1)
    elif ix:
        drop = ['mrg']
        df = _drap(df, ['lvl', 'year'], drop=drop)
    else:
        drop = ['unit']
        df = _drap(df, ['value', 'year'], drop=drop)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)

    return(df)


def _retr_land_emission(ds, tec, units, convert=1):
    """ Retrieve emissions of land-use technologies

    Parameters
    ----------
    ds : ix-datastructure
    tec : string
        emission type
    units : string
        see unit doc
    convert : integer
        switch to convert units (optional, 0 = False, 1 = True (default))

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    filter = {'emission': [tec]}
    df = ds.par('land_emission', filter)
    if df.empty:
        print((inspect.stack()[0][3], ': parameter land_emission', tec,
               ' dataframe empty. Please check that correct version of the land emulator is being used'))
        sys.exit(1)
    else:
        drop = ['emission']
        df = _drap(df, ['value', 'year'], drop=drop)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    if convert and units is not None:
        df = _convert_units(df, units)
    df = _clean_up_formatting(df)

    return(df)


def _retr_land_output(ds, filter, units, convert=1):
    """ Retrieve emissions of land-use technologies

    Parameters
    ----------
    ds : ix-datastructure
    filter : dictionary
        specific to 'land_output' table
    units : string
        see unit doc
    convert : integer
        switch to convert units (optional, 0 = False, 1 = True (default))

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    df = ds.par('land_output', filter)
    if df.empty:
        print((inspect.stack()[0][3], ': parameter land_output', filter,
               ' dataframe empty. Please check that correct version of the land emulator is being used'))
        sys.exit(1)
    else:
        drop = ['commodity', 'level', 'time']
        df = _drap(df, ['value', 'year'], drop=drop)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    if convert and units is not None:
        df = _convert_units(df, units)
    df = _clean_up_formatting(df)

    return(df)


def _retr_land_use(ds, filter, units, convert=1):
    """ Retrieve land use by type of land-use technologies

    Parameters
    ----------
    ds : ix-datastructure
    filter : dictionary
        specific to 'land_output' table
    units : string
        see unit doc
    convert : integer
        switch to convert units (optional, 0 = False, 1 = True (default))

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    df = ds.par('land_use', filter)
    if df.empty:
        print((inspect.stack()[0][3], ': parameter land_use', filter,
               ' dataframe empty. Please check that correct version of the land emulator is being used'))
        sys.exit(1)
    else:
        drop = ['land_type']
        df = _drap(df, ['value', 'year'], drop=drop)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    if convert and units is not None:
        df = _convert_units(df, units)
    df = _clean_up_formatting(df)

    return(df)


def _retr_emiss(ds, emission, type_tec):
    """ Retrieve emissions

    Parameters
    ----------
    ds : ix-datastructure
    emission : string
        emission type
    type_tec : string
        'all' or 'cumulative'

    Returns
    -------
    df: dataframe
        index: Region, Technology
    """

    filter = {'emission': [emission], 'type_tec': [type_tec]}
    df = ds.var('EMISS', filter)
    if df.empty:
        print((inspect.stack()[0][
              3], ': variable EMISS dataframe empty'))
        df = _make_emptydf(emission)
    else:
        drop = ['mrg', 'type_tec']
        df = _drap(df, ['lvl', 'year'], drop=drop)

    df = _clean_up_regions(df)
    df = _clean_up_years(df, method='zero')
    df = _clean_up_formatting(df)

    return(df)

# def _retr_historical_emission():
#	df = ds.par('historical_emission',
