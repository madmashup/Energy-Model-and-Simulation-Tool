# Input data gdx files for MESSAGEix

This is the default folder for the gdx input files 
for a MESSAGEix scenario instance,
which will be read by GAMS when solving the MESSAGEix model.

**Please do not commit gdx files to the GitHub repository!**

The gdx files have to be generated from an ixmp.Scenario instance
based on the MESSAGE scheme via the Python or R interface
of the ix modeling platform [(ixmp)](https://github.com/iiasa/ixmp).
